..
   Copyright 2017-2023 AVSystem <avsystem@avsystem.com>
   AVSystem Anjay LwM2M SDK
   All rights reserved.

   Licensed under the AVSystem-5-clause License.
   See the attached LICENSE file for details.

:orphan:

.. meta::

    :http-equiv=Refresh: 1; url=NetworkingAPI-Minimal.html

.. title:: Redirection

↳ :doc:`NetworkingAPI-Minimal`
==============================
