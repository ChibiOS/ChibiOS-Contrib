This is the Wiznet/ioLibrary-Driver as downloaded from
https://github.com/Wiznet/ioLibrary_Driver/commit/3847fb3b5d1a6a1dc8f7e38b239d7e57951f3a8a

Apply the ioLibrary-Driver-3847fb3b5d1a6a1dc8f7e38b239d7e57951f3a8a.patch
before using ioLibrary-Driver with ChibiOS.

Happy Ethernetting!
