/*
    ChibiOS - Copyright (C) 2023 Xael South

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package simpleCoapClientPackage;

import java.io.IOException;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.Utils;
import org.eclipse.californium.elements.exception.ConnectorException;


public class SimpleCoapClient
{
    public static void main(String[] args) throws ConnectorException, IOException {
        CoapClient client = new CoapClient("coap://localhost:5683/res_lvl_1/res_lvl_2/res_lvl_2a");

                CoapResponse get_response = client.get();
                if (get_response!= null)
                {
                        System.out.println(get_response.getCode());
                        System.out.println(get_response.getOptions());
                        System.out.println(get_response.getResponseText());
                        System.out.println(get_response.getPayload());
                        System.out.println(Utils.prettyPrint(get_response));
                }
                else
                {
                        System.out.println("No response received.");
                }

                byte[] data = "Request from CoapClient".getBytes();

                CoapResponse put_response = client.put(data, data.length);
                if (put_response!= null)
                {
                        System.out.println(put_response.getCode());
                        System.out.println(put_response.getOptions());
                        System.out.println(put_response.getResponseText());
                        System.out.println(get_response.getPayload());
                        System.out.println(Utils.prettyPrint(put_response));
                }
                else
                {
                        System.out.println("No response received.");
                }

                CoapResponse post_response = client.post(data, data.length);
                if (post_response!= null)
                {
                        System.out.println(post_response.getCode());
                        System.out.println(post_response.getOptions());
                        System.out.println(post_response.getResponseText());
                        System.out.println(get_response.getPayload());
                        System.out.println(Utils.prettyPrint(post_response));
                }
                else
                {
                        System.out.println("No response received.");
                }

                client.shutdown();
    }
 }

