/*
    ChibiOS - Copyright (C) 2023 Xael South

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.server.resources.CoapExchange;
import res.UserResource;

public class SimpleCoapServer {

    public static void main(String[] args) {
        CoapServer server = new CoapServer(5683);

        server.add(
                new CoapResource("res_lvl_1")
                      .add(new CoapResource("res_lvl_2")
                            .add(new UserResource("res_lvl_2a"))
                            .add(new UserResource("res_lvl_2b"))
                            .add(new UserResource("res_lvl_2c"))
                            .add(new UserResource("res_lvl_2d"))
                          )
                );

        server.add(
                new CoapResource("another_res_lvl_1")
                      .add(new UserResource("another_res_lvl_2")
                      )
                );

        server.start();
    }
}
