/*
    ChibiOS - Copyright (C) 2023 Xael South

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package simpleDtlsCoapClientPackage;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.Utils;
import org.eclipse.californium.core.network.CoapEndpoint;
import org.eclipse.californium.core.network.config.NetworkConfig;
import org.eclipse.californium.elements.exception.ConnectorException;
import org.eclipse.californium.scandium.DTLSConnector;
import org.eclipse.californium.scandium.config.DtlsConnectorConfig;
import org.eclipse.californium.scandium.dtls.pskstore.StaticPskStore;

public class ExampleDTLSClient {
    private static final Logger LOG = Logger.getLogger(ExampleDTLSClient.class.getName());

    private static final int DEFAULT_SECURE_PORT = 5684;

    private CoapEndpoint coapEndpoint;

    public ExampleDTLSClient(NetworkConfig config) {
        String DEFAULT_IDENTITY = "12345";
        byte DEFAULT_PSK[] = new byte[]{(byte) 5, (byte) 4, (byte) 3, (byte) 2, (byte) 1};
        StaticPskStore pskStore = new StaticPskStore(DEFAULT_IDENTITY, DEFAULT_PSK);

        DtlsConnectorConfig.Builder builder = new DtlsConnectorConfig.Builder();
        builder.setAddress(new InetSocketAddress(0));
        builder.setPskStore(pskStore);
        DTLSConnector dtlsConnector = new DTLSConnector(builder.build());

        CoapEndpoint.Builder coapBuilder = new CoapEndpoint.Builder();
        coapBuilder.setConnector(dtlsConnector);
        coapBuilder.setNetworkConfig(config);
        coapEndpoint = coapBuilder.build();
    }

    public CoapEndpoint endpoint() { return coapEndpoint; }

    public static void main(String[] args) throws InterruptedException, ConnectorException, IOException {
        CoapClient client = new CoapClient("coaps://localhost:5684/res_lvl_1/res_lvl_2/res_lvl_2a");

        NetworkConfig config = NetworkConfig.getStandard();
        ExampleDTLSClient dtls = new ExampleDTLSClient(config);
        client.setEndpoint(dtls.endpoint());

        CoapResponse get_response = client.get();
        if (get_response!= null)
        {
            System.out.println(get_response.getCode());
            System.out.println(get_response.getOptions());
            System.out.println(get_response.getResponseText());
            System.out.println(get_response.getPayload());
            System.out.println(Utils.prettyPrint(get_response));
        }
        else
        {
            System.out.println("No response received.");
        }

        byte[] data = "Request from CoapClient".getBytes();

        CoapResponse put_response = client.put(data, data.length);
        if (put_response!= null)
        {
            System.out.println(put_response.getCode());
            System.out.println(put_response.getOptions());
            System.out.println(put_response.getResponseText());
            System.out.println(get_response.getPayload());
            System.out.println(Utils.prettyPrint(put_response));
        }
        else
        {
            System.out.println("No response received.");
        }

        CoapResponse post_response = client.post(data, data.length);
        if (post_response!= null)
        {
            System.out.println(post_response.getCode());
            System.out.println(post_response.getOptions());
            System.out.println(post_response.getResponseText());
            System.out.println(get_response.getPayload());
            System.out.println(Utils.prettyPrint(post_response));
        }
        else
        {
            System.out.println("No response received.");
        }

        client.shutdown();
    }
}
