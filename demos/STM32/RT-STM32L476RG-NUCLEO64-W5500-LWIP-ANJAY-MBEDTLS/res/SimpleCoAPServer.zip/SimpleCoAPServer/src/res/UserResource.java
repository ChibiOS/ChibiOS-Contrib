/*
    ChibiOS - Copyright (C) 2023 Xael South

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package res;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.server.resources.CoapExchange;

    public class UserResource extends CoapResource
    {
        public UserResource(String resource_name) {
            super(resource_name);
        }
       private byte[] processRequest(byte[] request) {
            return "UserResource".getBytes();
        }

        @Override
        public void handleGET(CoapExchange exchange)
        {
            showUriAndQuery(this.getName(), exchange, null);

            byte[] request = exchange.getRequestPayload();
            System.out.println(request);

            byte[] response = processRequest(request);
            System.out.println(response);

            exchange.respond(ResponseCode.CONTENT, response);
        }

        @Override
        public void handlePOST(CoapExchange exchange) {
            showUriAndQuery(this.getName(), exchange, null);

            byte[] request = exchange.getRequestPayload();
            System.out.println(request);

            // Do something with request.

            exchange.respond(ResponseCode.CHANGED);
        }

        @Override
        public void handlePUT(CoapExchange exchange) {
            showUriAndQuery(this.getName(), exchange, null);

            byte[] request = exchange.getRequestPayload();
            System.out.println(request);

            // Do something with request.

            exchange.respond(ResponseCode.CHANGED);
        }

        public static void showUriAndQuery(String uri, CoapExchange exchange, byte[] payload) {

            final OptionSet options = exchange.getRequestOptions();
            final List<String> optionList = options.getUriQuery();

            System.out.println("Request: " + uri);
            for (String s: optionList) System.out.println(s);

            if (payload != null) {
                System.out.format("Payload %s, payloadlen = %d", payload.toString(), payload.length);
            }
        }
    }
