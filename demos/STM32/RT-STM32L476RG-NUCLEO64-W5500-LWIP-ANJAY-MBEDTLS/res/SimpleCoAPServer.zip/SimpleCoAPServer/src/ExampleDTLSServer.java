/*
    ChibiOS - Copyright (C) 2023 Xael South

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package simpleDtlsCoapServerPackage;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.security.*;
import java.util.logging.Logger;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.network.CoapEndpoint;
import org.eclipse.californium.core.network.config.NetworkConfig;
import org.eclipse.californium.elements.tcp.TlsServerConnector;
import org.eclipse.californium.elements.tcp.TcpServerConnector;
import org.eclipse.californium.scandium.DTLSConnector;
import org.eclipse.californium.scandium.config.DtlsConnectorConfig;
import org.eclipse.californium.scandium.dtls.pskstore.StaticPskStore;
import res.UserResource;

import javax.net.ssl.SSLContext;

public class ExampleDTLSServer {
    private static final Logger LOG = Logger.getLogger(ExampleDTLSServer.class.getName());

    private static final int TCP_DEFAULT_PORT = 6683;
    private static final int TLS_DEFAULT_SECURE_PORT = 6684;
    private static final int DEFAULT_PORT = 5683    ;
    private static final int DEFAULT_SECURE_PORT = 5684;
    private CoapEndpoint coapEndpoint;

    public ExampleDTLSServer(NetworkConfig config)
    {
        String DEFAULT_IDENTITY = "12345";
        byte DEFAULT_PSK[] = new byte[]{(byte) 5, (byte) 4, (byte) 3, (byte) 2, (byte) 1};
        StaticPskStore pskStore = new StaticPskStore(DEFAULT_IDENTITY, DEFAULT_PSK);

        DtlsConnectorConfig.Builder builder = new DtlsConnectorConfig.Builder();
        builder.setAddress(new InetSocketAddress(DEFAULT_SECURE_PORT));
        builder.setPskStore(pskStore);
        builder.setClientAuthenticationRequired(false);
        builder.setRetransmissionTimeout(30);
        DTLSConnector dtlsConnector = new DTLSConnector(builder.build());

        CoapEndpoint.Builder coapBuilder = new CoapEndpoint.Builder();
        coapBuilder.setConnector(dtlsConnector);
        coapBuilder.setNetworkConfig(config);
        coapEndpoint = coapBuilder.build();
    }

    public CoapEndpoint endpoint() { return coapEndpoint; }

    public static void main(String[] args) throws IOException {

        NetworkConfig config = NetworkConfig.getStandard();

        CoapServer server = new CoapServer();

        {
            ExampleDTLSServer dtls = new ExampleDTLSServer(config);
            server.addEndpoint(dtls.endpoint()); // secured UDP connection
        }

        {
            CoapEndpoint.Builder udp_ep = new CoapEndpoint.Builder();
            udp_ep.setNetworkConfig(config).setPort(DEFAULT_PORT);
            server.addEndpoint(udp_ep.build()); // unsecured UDP connection
        }

        {
            CoapEndpoint.Builder builder = new CoapEndpoint.Builder();
            TcpServerConnector tcp_ep = new TcpServerConnector(new InetSocketAddress(TCP_DEFAULT_PORT), 8, 100);
            builder.setConnector(tcp_ep);
            builder.setNetworkConfig(config);
            server.addEndpoint(builder.build()); // unsecured TCP connection
        }

        {
            CoapEndpoint.Builder builder = new CoapEndpoint.Builder();
            SSLContext serverSslContext = null;

            try {
                serverSslContext = SSLContext.getInstance("TLS");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

            TlsServerConnector tls_ep = new TlsServerConnector(serverSslContext, new InetSocketAddress(TLS_DEFAULT_SECURE_PORT), 8, 100);
            builder.setConnector(tls_ep);
            builder.setNetworkConfig(config);
            server.addEndpoint(builder.build()); // secured TCP connection
        }

        server.add(
                new CoapResource("res_lvl_1")
                        .add(new CoapResource("res_lvl_2")
                                .add(new UserResource("res_lvl_2a"))
                                .add(new UserResource("res_lvl_2b"))
                                .add(new UserResource("res_lvl_2c"))
                                .add(new UserResource("res_lvl_2d"))
                        )
        );

        server.add(
                new CoapResource("another_res_lvl_1")
                        .add(new UserResource("another_res_lvl_2")
                        )
        );

        server.start();
    }
}
